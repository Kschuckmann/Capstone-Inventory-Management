module schuckmann.pac482 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    exports schuckmann.C868;
    opens schuckmann.C868 to javafx.fxml;
    exports schuckmann.C868.Controllers;
    opens schuckmann.C868.Controllers to javafx.fxml;
    exports schuckmann.C868.model;
    opens schuckmann.C868.model to javafx.fxml;
}