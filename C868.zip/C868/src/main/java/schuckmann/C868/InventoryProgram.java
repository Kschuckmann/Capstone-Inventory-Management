package schuckmann.C868;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


/**
 *Runtime Errors, improper code for start in the FXML files. Whole project
 * restarted to fix system errors.
 * @author Karl Schuckmann
 * Parts of FXML for Modify Product edited
 */
public class InventoryProgram extends Application {
    /**
     *
     * @param args
     */
    public static void main(String[]args) {
        inventoryDB.startConnection();
        launch(args);
        inventoryDB.endConnect();
    }
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/loginScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
