package schuckmann.C868;

import java.sql.Connection;
import java.sql.DriverManager;

public abstract class inventoryDB {
    public static Connection connection;
    private static final String url = "jdbc:mysql://localhost/inventorydb?connectionTimeZone = SERVER";
    private static final String driver = "com.mysql.cj.jdbc.Driver";

    private static final String user = "sqlUser";
    private static final String pass = "Passw0rd!";
    public static void startConnection(){
        try{
            Class.forName(driver);
            connection = DriverManager.getConnection(url,user,pass);
            System.out.println("Connected");
        }catch(Exception e) {
            System.out.println(e);
        }
    }
    public static void endConnect(){
        try{
            connection.close();
        }catch (Exception e){
        }
    }
}
