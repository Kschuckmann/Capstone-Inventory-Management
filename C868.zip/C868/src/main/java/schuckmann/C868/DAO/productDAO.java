package schuckmann.C868.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import schuckmann.C868.model.Product;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static schuckmann.C868.inventoryDB.connection;

public class productDAO {

    public static ObservableList<Product> allProducts()throws SQLException {
        ObservableList<Product> products = FXCollections.observableArrayList();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM inventorydb.product");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            products.add(productListBuild(resultSet));
        }
        return products;
    }

    public static Product productListBuild(ResultSet resultSet)throws SQLException{
        int productID = resultSet.getInt("productID");
        String productName= resultSet.getString("name");
        double price = resultSet.getDouble("price");
        int stock = resultSet.getInt("stock");
        int min = resultSet.getInt("min");
        int max = resultSet.getInt("max");

        return new Product(productID,productName,price,stock,min,max);
    }
    public static int maxProductID() throws SQLException {
        try(PreparedStatement preparedStatement = connection.prepareStatement("SELECT MAX(productID) FROM inventorydb.product")){
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return resultSet.getInt("MAX(productID)")+1;
            }
        }catch (SQLException e){
            System.out.println(e);
        }
        return 1;
    }
    public static boolean deleteProduct(int productID) throws SQLException{
        int removeProduct =0;
        try(PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM inventorydb.product WHERE productID = ?")){
            preparedStatement.setInt(1,productID);
            removeProduct=preparedStatement.executeUpdate();
        }catch (SQLException e){
            System.out.println(e);
        }
        return removeProduct >0;
    }
    public static boolean addProduct(Product product) throws SQLException{
        int newProd = 0;
        try(PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO inventorydb.product (productID,name,price,stock,min,max) Values (?,?,?,?,?,?)")){
            preparedStatement.setInt(1,product.getProductID());
            preparedStatement.setString(2,product.getName());
            preparedStatement.setDouble(3,product.getPrice());
            preparedStatement.setInt(4,product.getInStock());
            preparedStatement.setInt(5,product.getMin());
            preparedStatement.setInt(6,product.getMax());
            newProd = preparedStatement.executeUpdate();
        }catch (SQLException e){
            System.out.println(e + "Here");
        }
        return newProd >0;
    }
    public static boolean updateProduct(Product product)throws SQLException{
        int updateProd = 0;
        try(PreparedStatement preparedStatement = connection.prepareStatement("UPDATE inventorydb.product SET name = ?, price = ?, stock = ?,min = ?,max = ? WHERE productID = ?")) {
            preparedStatement.setString(1, product.getName());
            preparedStatement.setDouble(2, product.getPrice());
            preparedStatement.setInt(3,product.getInStock());
            preparedStatement.setInt(4, product.getMin());
            preparedStatement.setInt(5, product.getMax());
            preparedStatement.setInt(6, product.getProductID());

            updateProd = preparedStatement.executeUpdate();
            System.out.println(updateProd);
        }catch (SQLException e){
            System.out.println(e);
        }
        return updateProd >0;
    }
}
