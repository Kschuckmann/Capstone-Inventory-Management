package schuckmann.C868.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import schuckmann.C868.model.Part;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import static schuckmann.C868.inventoryDB.connection;

public class partDAO {
    public static ObservableList<Part> allParts() throws SQLException {
        ObservableList<Part> partList = FXCollections.observableArrayList();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM inventorydb.part");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            partList.add(partListBuild(resultSet));
        }
        return partList;
    }
    public static int maxPartID() throws  SQLException {
        try(PreparedStatement preparedStatement = connection.prepareStatement("SELECT MAX(idpart) FROM inventorydb.part")){
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return resultSet.getInt("MAX(idpart)")+1;
            }
        }catch (SQLException e){

        }
        return 1;
    }
    public static Part partListBuild(ResultSet resultSet)throws SQLException{
        int id = resultSet.getInt("idpart");
        String name = resultSet.getString("name");
        double price = resultSet.getDouble("price");
        int stock = resultSet.getInt("stock");
        int min = resultSet.getInt("min");
        int max = resultSet.getInt("max");

        return new Part(id,name,price,stock,min,max);
    }
    public static boolean addPart(Part part)throws SQLException{
        int newPartRow = 0;
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        try(PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO inventorydb.part(idpart,name,price,stock,min,max,timestamp) Values (?,?,?,?,?,?,?)")){
            preparedStatement.setInt(1,part.getId());
            preparedStatement.setString(2,part.getName());
            preparedStatement.setDouble(3,part.getPrice());
            preparedStatement.setInt(4,part.getStock());
            preparedStatement.setInt(5,part.getMin());
            preparedStatement.setInt(6,part.getMax());
            preparedStatement.setTimestamp(7,timestamp);
            newPartRow = preparedStatement.executeUpdate();
            System.out.println(timestamp);
            System.out.println(newPartRow);
        }catch (SQLException e) {
            System.out.println("Error");
        }
        return newPartRow > 0;
    }
    public static boolean updatePart(Part part)throws  SQLException{
        int updatePart = 0;
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        try(PreparedStatement preparedStatement = connection.prepareStatement("UPDATE inventorydb.part SET name = ?, price = ?, stock = ?, min = ?, max = ?, timestamp = ? WHERE idpart = ?")){
            preparedStatement.setString(1,part.getName());
            preparedStatement.setDouble(2,part.getPrice());
            preparedStatement.setInt(3,part.getStock());
            preparedStatement.setInt(4,part.getMin());
            preparedStatement.setInt(5,part.getMax());
            preparedStatement.setTimestamp(6,timestamp);
            preparedStatement.setInt(7,part.getId());

            updatePart = preparedStatement.executeUpdate();
           System.out.println(updatePart);
        }catch (SQLException e){
            System.out.println("Error updating");
        }
        return updatePart >0;
    }
    public static boolean deletePart(int partID)throws SQLException{
        int deletePart = 0;
        try(PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM inventorydb.part WHERE idpart = ?")){
            preparedStatement.setInt(1,partID);
            deletePart=preparedStatement.executeUpdate();
            System.out.println(deletePart);
        }catch (SQLException e){
            System.out.println("Error Here");
        }
        return deletePart>0;
    }
}
