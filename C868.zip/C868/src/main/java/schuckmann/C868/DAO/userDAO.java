package schuckmann.C868.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static schuckmann.C868.inventoryDB.connection;
public class userDAO {
    public static boolean userLogin(String username,String password)throws SQLException{
        try(PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM user WHERE loginName = ? and psw = ?")){
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return true;
            }
        }catch (SQLException e){

        }
        return false;
    }
}
