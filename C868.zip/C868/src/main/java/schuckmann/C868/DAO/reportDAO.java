package schuckmann.C868.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import schuckmann.C868.model.Report;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import static schuckmann.C868.inventoryDB.connection;

public class reportDAO {

    public static ObservableList<Report> allPartReport() throws SQLException{
        ObservableList<Report> reports = FXCollections.observableArrayList();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from inventorydb.part");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            reports.add(reportListBuild(resultSet));
        }
        return reports;
    }
    public static Report reportListBuild(ResultSet resultSet) throws SQLException{
        String name = resultSet.getString("name");
        int stock = resultSet.getInt("stock");
        Timestamp timestamp = resultSet.getTimestamp("timestamp");
        return new Report(name,stock,timestamp);
    }
}
