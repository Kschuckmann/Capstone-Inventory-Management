package schuckmann.C868.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import schuckmann.C868.DAO.partDAO;
import schuckmann.C868.DAO.productDAO;

import java.sql.SQLException;

/**
 * @author Karl Schuckmann
 **/

/**
 * Logic Error, parts of this file were named wrong, renamed according to UML
 */
public class Inventory {
    private static ObservableList<Product> productInventory;

    static {
        try {
            productInventory = productDAO.allProducts();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private static ObservableList<Part> partInventory;

    static {
        try {
            partInventory = partDAO.allParts();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void addPart(Product productAddition) {
        if(productAddition != null) {
            productInventory.add(productAddition);
        }
    }
    public static boolean removeProduct (int productToRemove) {
        for (int i = 0; i < productInventory.size(); i++) {
            if (productInventory.get(i).getProductID() == productToRemove) {
                productInventory.remove(i);
                return true;
            }
        }
        return false;
    }
    public static Product lookUpProduct(int productID) {
        for(Product product: Inventory.getAllProducts()){
            while (product.getProductID() == productID)
                return product;
        }
        return null;
    }
    public static ObservableList<Product> lookupProduct(String productName){
        ObservableList<Product> ProductName = FXCollections.observableArrayList();

        for (Product product: productInventory) {
            if (product.getName().contains(productName)) {
                ProductName.add(product);
            }
        }
        return ProductName;
    }
    public static void updateProduct(Product product) {
        for (int i = 0; i < productInventory.size(); i++) {
            if (productInventory.get(i).getProductID() == product.getProductID()) {
                productInventory.set(i, product);
                break;
            }
        }
        return;
    }
    public static void addPart(Part addPart) {
        if(addPart != null) {
            partInventory.add(addPart);
        }
    }
    public static boolean deletePart(Part partDeletion) {
        for (int i = 0; i < partInventory.size(); i++) {
            if (partInventory.get(i).getId() == partDeletion.getId()) {
                partInventory.remove(i);
                return true;
            }
        }
        return false;
    }
    public static Part partLookup(int partLookUp){
        if (!partInventory.isEmpty()){
            for (int i = 0; i < partInventory.size(); i++) {
                if(partInventory.get(i).getId() == partLookUp) {
                    return partInventory.get(i);
                }
            }
        }
        return null;
    }
    public static ObservableList<Part> partLookup(String partNameLookUp) {
        if(!partInventory.isEmpty()) {
            ObservableList searchPartsList = FXCollections.observableArrayList();
            for (Part m : getAllParts()) {
                if (m.getName().contains(partNameLookUp)) {
                    searchPartsList.add(m);
                }
            }
            return searchPartsList;
        }
        return null;
    }
    public static void updatePart(Part partUpdating) {
        for (int i = 0; i < partInventory.size(); i++) {
            if (partInventory.get(i).getId() == partUpdating.getId()) {
                partInventory.set(i, partUpdating);
                break;
            }
        }
        return;
    }

    public static ObservableList<Product> getAllProducts() {
        return productInventory;
    }
    public static ObservableList<Part> getAllParts() {
        return partInventory;
    }
    public static int partListSize() {
        return partInventory.size();
    }
    public static int productListSize() {
        return productInventory.size();
    }
}
//create id for part and product, needs to be static to return and auto implement, partId++, productID++, intialize to 1
