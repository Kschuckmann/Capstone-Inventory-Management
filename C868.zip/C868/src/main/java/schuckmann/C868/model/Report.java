package schuckmann.C868.model;

import java.sql.Timestamp;

public class Report {
    private String name;
    private int stock;
    private Timestamp timestamp;

    public Report(String name, int stock, Timestamp timestamp) {
        this.name = name;
        this.stock = stock;
        this.timestamp = timestamp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
}
