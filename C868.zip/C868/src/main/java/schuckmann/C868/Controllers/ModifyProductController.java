package schuckmann.C868.Controllers;

import javafx.event.ActionEvent;
import javafx.scene.control.*;
import schuckmann.C868.DAO.productDAO;
import schuckmann.C868.model.Product;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * FXML Controller class
 *
 * @Author Karl Schuckmann
 */
/**
 * Logical error, parts of code were interfering with running
 * the FXML properly
 * Also, issues with launching panel from Main Screen, unsure how to fix at
 * this time.
 * Future enhancement: further simplify code, and cut off an excess code that isn't needed
 * Can also be simplfied in some sections of code
 */

public class ModifyProductController implements Initializable {
    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField price;
    @FXML
    private TextField count;
    @FXML
    private TextField min;
    @FXML
    private TextField max;
    int productID;

    /**
     * Starts controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    public void productInfo(Product product){
        productID = product.getProductID();
        name.setText(product.getName());
        price.setText(Double.toString(product.getPrice()));
        count.setText(Integer.toString(product.getInStock()));
        min.setText(Integer.toString(product.getMin()));
        max.setText(Integer.toString(product.getMax()));
    }

    private void resetFieldsStyle() {
        name.setStyle("-fx-border-color: lightgray");
        count.setStyle("-fx-border-color: lightgray");
        price.setStyle("-fx-border-color: lightgray");
        min.setStyle("-fx-border-color: lightgray");
        max.setStyle("-fx-border-color: lightgray");
    }

    @FXML
    void saveProductEvent(ActionEvent event) {
        resetFieldsStyle();
        String productName = name.getText();
        Double productPrice = Double.parseDouble(price.getText());
        Integer productStock = Integer.parseInt(count.getText());
        Integer productMin = Integer.parseInt(min.getText());
        Integer productMax = Integer.parseInt(max.getText());
        if (productName.isEmpty()||String.valueOf(productPrice).isEmpty()||
                String.valueOf(productStock).isEmpty()||String.valueOf(productMin).isEmpty()
                ||String.valueOf(productMax).isEmpty()){
            Alert warning = new Alert(AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("Empty Fields");
            warning.setContentText("Please ensure all fields are full");
            warning.showAndWait();
            return;
        } else if(Integer.valueOf(productMax)<=Integer.valueOf(productMin)) {
            Alert warning = new Alert(AlertType.WARNING);
            warning.setTitle("Error");
            warning.setHeaderText("Error");
            warning.setContentText("Maximum product is less then minimum!");
            warning.showAndWait();
            return;
        }else{
            try{
                Product modProd = new Product(productID,productName,productPrice,productStock,productMin,productMax);
                productDAO.updateProduct(modProd);
            }catch (SQLException e){
                System.out.println(e);
            }
        }
        mainScreen(event);
    }
    @FXML
    private void mainScreen(Event event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/MainScreen.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void saveProduct() {

    }
    // cancels modifying the product
    @FXML
    private void cancelModify(ActionEvent event) {
        boolean cancel = AlertMessage.cancel();
        if (cancel) {
            mainScreen(event);
        } else {
            return;
        }
    }

}