package schuckmann.C868.Controllers;

import javafx.collections.ObservableList;
import javafx.scene.control.*;
import schuckmann.C868.DAO.partDAO;
import schuckmann.C868.model.Inventory;
import schuckmann.C868.model.Part;
import schuckmann.C868.model.Product;
import schuckmann.C868.DAO.productDAO;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 * Controls the main screen
 * @author Karl Schuckmann
 */

/**
 * Runtime error in program, had to remake program from scratch with CI
 * Change the way tables were done, simplified code
 *
 * Future Enhancement: Reduce Excess code, and simplify more of the code.
 * Another enhancement could be to allow a description of the product as well as parts
 */

public class MainScreenController implements Initializable {
    // Search string input
    @FXML private TextField partSearchBox;
    // Product Search String
    @FXML private TextField productSearchBox;
    //Table of all parts information
    @FXML private TableView<Part> mainScreenPartsTable;
    // Table of all products' information.

    @FXML private TableView<Product> mainScreenProductsTable;
    @FXML private TableColumn<Product, Integer> productIDCol;
    @FXML private TableColumn<Product, String> productNameCol;
    @FXML private TableColumn<Product, Integer> productInventoryCol;
    @FXML private TableColumn<Product, Double> productPriceCol;
    @FXML private TableColumn<Part, Integer> partIDCol;
    @FXML private TableColumn<Part, String> partNameCol;
    @FXML private TableColumn<Part, Integer> partInventoryCol;
    @FXML private TableColumn<Part, Double> partPriceCol;
    // Begins controller class
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try{
            ObservableList<Part> parts = partDAO.allParts();
            mainScreenPartsTable.setItems(parts);
            ObservableList<Product> products = productDAO.allProducts();
            mainScreenProductsTable.setItems(products);
        }catch (SQLException e) {

        }
        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        productIDCol.setCellValueFactory(new PropertyValueFactory<>("productID"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryCol.setCellValueFactory(new PropertyValueFactory<>("inStock"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    @FXML
    private void exitProgram (ActionEvent event) {
        Platform.exit();
    }
    @FXML
    private void exitProgramButton(MouseEvent event) {
        Platform.exit();
    }
    // Search System for Inventory
    @FXML
    private void searchForPart(MouseEvent event) {
        String searchText = partSearchBox.getText();
        ObservableList<Part> results = Inventory.partLookup(searchText);
        try {
            while (results.size() == 0) {
                int partID = Integer.parseInt(searchText);
                results.add(Inventory.partLookup(partID));
            }
            mainScreenPartsTable.setItems(results);
        }catch (NumberFormatException e) {
            Alert noPart = new Alert(AlertType.ERROR);
            noPart.setTitle("Error Message");
            noPart.setContentText("Part not found");
            noPart.showAndWait();
        }
    }
    @FXML
    void mainScreenProductSearch(MouseEvent event) {
        String searchText = productSearchBox.getText();
        ObservableList<Product> results = Inventory.lookupProduct(searchText);
        try {
            while (results.size() == 0 ) {
                int productID = Integer.parseInt(searchText);
                results.add(Inventory.lookUpProduct(productID));
            }
            mainScreenProductsTable.setItems(results);
        } catch (NumberFormatException e) {
            Alert noProd = new Alert(Alert.AlertType.ERROR);
            noProd.setTitle("Error Message");
            noProd.setContentText("Product not found");
            noProd.showAndWait();
        }
    }
    // Clears search box and shows both parts and products
    @FXML
    void clearText(MouseEvent event) {
        Object source = event.getSource();
        TextField field = (TextField) source;
        field.setText("");
        if (partSearchBox == field) {
            if (Inventory.getAllParts().size() != 0) {
                mainScreenPartsTable.setItems(Inventory.getAllParts());
            }
        }
        if (productSearchBox == field) {
            if (Inventory.getAllProducts().size() != 0) {
                mainScreenProductsTable.setItems(Inventory.getAllProducts());
            }
        }
    }
    //Changes screen to AddParts section
    @FXML
    private void addPart(MouseEvent event) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/AddPart.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            System.out.println("Error");
        }
    }
    // Change to modifyPart Screen
    @FXML
    private void modifyPart(MouseEvent event){
        if(mainScreenPartsTable.getSelectionModel().isEmpty()){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("No Selection");
            warning.setContentText("Please select a part");
            warning.showAndWait();
        }else {
            Part selectedPart = mainScreenPartsTable.getSelectionModel().getSelectedItem();
            String partName = selectedPart.getName();
            try {
                    System.out.println(partName);
                System.out.println("Opening Modify");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/ModifyPart.fxml"));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.setResizable(false);
                ModifyPartController modifyPartController = loader.getController();
                modifyPartController.pullParts(selectedPart);
                stage.show();
            }catch (IOException e){
                System.out.println(e);
            }
        }
    }
    // Event where part is deleted upon clicking.
    @FXML
    private void deletePart (MouseEvent event) {
        if(mainScreenPartsTable.getSelectionModel().isEmpty()){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("No Selection");
            warning.setContentText("Please select a part");
            warning.showAndWait();
        }else{
            Part part = mainScreenPartsTable.getSelectionModel().getSelectedItem();
            int partID = part.getId();
            String partName = part.getName();
            Alert warning = new Alert(AlertType.CONFIRMATION);
            warning.setTitle("Confirm");
            warning.setHeaderText("Delete Part?");
            warning.setContentText("Do you wish to remove:\n" + partName);
            Optional<ButtonType> check = warning.showAndWait();
            if(check.isPresent()&& check.get()==ButtonType.OK){
                try{
                    if (partDAO.deletePart(partID)){
                        System.out.println("Part removed");
                }else{
                        System.out.println("Part not removed");
                    }
                    mainScreenPartsTable.setItems(partDAO.allParts());
            }catch(SQLException e){
                    throw new RuntimeException(e);
                }
        }

    }

}

    // Add Product upon clicking button
    @FXML
    private void addProduct(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/AddProduct.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();

        } catch (IOException e) {

        }
    }
    @FXML
    private void deleteProduct(MouseEvent event)throws IOException{
        if(mainScreenProductsTable.getSelectionModel().isEmpty()){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("No Selection");
            warning.setContentText("Please select a product");
            warning.showAndWait();
        }else{
            Product product = mainScreenProductsTable.getSelectionModel().getSelectedItem();
            int productID = product.getProductID();
            String productName = product.getName();
            Alert warning = new Alert(AlertType.CONFIRMATION);
            warning.setTitle("Confirm");
            warning.setHeaderText("Delete Product?");
            warning.setContentText("Do you wish to remove:\n" +productName);
            Optional<ButtonType> check = warning.showAndWait();
            if(check.isPresent()&& check.get()==ButtonType.OK){
                try{
                    if (productDAO.deleteProduct(productID)){
                        System.out.println("Product removed");
                    }else{
                        System.out.println("Product not removed");
                    }
                    mainScreenProductsTable.setItems(productDAO.allProducts());
                }catch(SQLException e){
                    throw new RuntimeException(e);
                }
            }

        }
    }
    @FXML
    private void modifyProduct(MouseEvent event)throws IOException{
        if(mainScreenProductsTable.getSelectionModel().isEmpty()){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("No Selection");
            warning.setContentText("Please select a product");
            warning.showAndWait();
        }else {
            Product product = mainScreenProductsTable.getSelectionModel().getSelectedItem();
            try {
                System.out.println("Opening Modify");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/ModifyProduct.fxml"));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.setResizable(false);
                ModifyProductController modifyProductController = loader.getController();
                modifyProductController.productInfo(product);
                stage.show();
            }catch (IOException e){
                System.out.println(e);
            }
        }
    }

    @FXML
    public void reportButton(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/report.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        }catch (IOException e){
            System.out.println(e);

        }
    }


}