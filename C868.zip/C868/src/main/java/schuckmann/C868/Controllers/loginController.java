package schuckmann.C868.Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

import javafx.stage.Stage;
import schuckmann.C868.DAO.partDAO;
import schuckmann.C868.DAO.productDAO;
import schuckmann.C868.model.Part;
import schuckmann.C868.model.Product;

import static schuckmann.C868.DAO.userDAO.userLogin;
import static schuckmann.C868.inventoryDB.connection;

public class loginController {

    @FXML
    private Label loginTitle;
    @FXML
    private Label loginUsername;
    @FXML
    private TextField userNameInput;
    @FXML
    private Label passwordLabel;
    @FXML
    private TextField passwordInput;
    @FXML
    private Button loginButton;
    @FXML
    public void exitButton(ActionEvent actionEvent) throws IOException {

        System.exit(0);
    }
    @FXML
    public void loginButton(ActionEvent actionEvent) throws IOException, SQLException {
        String username = userNameInput.getText();
        String password = passwordInput.getText();
        if(userLogin(username,password)) {
               ObservableList<Part> parts = partDAO.allParts();
               ObservableList<Product> products = productDAO.allProducts();
               Parent parent = FXMLLoader.load(getClass().getResource("/schuckmann/C868/MainScreen.FXML"));
               Scene scene = new Scene(parent);
               Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
               stage.setScene(scene);
               stage.centerOnScreen();
               stage.show();

        }
    }

}
