package schuckmann.C868.Controllers;

import javafx.scene.control.Alert;
import schuckmann.C868.DAO.partDAO;
import schuckmann.C868.model.Inventory;
import schuckmann.C868.model.Part;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Random;
import java.util.ResourceBundle;

/**
 * FXML controller class, add part
 *
 * @author Karl Schuckmann
 */
/**
 * Logical error, parts of code were interfering with running
 * the FXML properly
 */
public class AddPartController implements Initializable {



    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField count;
    @FXML
    private TextField price;
    @FXML
    private TextField max;
    @FXML
    private TextField min;
    /**
     * Begins controller class
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        restartFields();
    }
    // Clears fields for controller
    private void restartFields() {
        name.setText("Part Name");
        count.setText("Inv Count");
        price.setText("Part Price");
        min.setText("Min");
        max.setText("Max");
    }
    //Creates Parts ID
    private void generatePartID() {
        boolean match;
        Random randomNum = new Random();
        Integer num = randomNum.nextInt(1000);
        if (Inventory.partListSize() == 0) {
            id.setText(num.toString());
        }
        if (Inventory.partListSize() == 1000) {
            AlertMessage.errorPart(3, null);
        } else {
            match = checkIfTaken(num);

            if (match == false) {
                id.setText(num.toString());
            } else {
                generatePartID();
            }
        }
    }
    //Checks if number is taken
    private boolean checkIfTaken(Integer num) {
        Part match = Inventory.partLookup(num);
        return match != null;
    }
    //Clears the text field when pressed
    @FXML
    private void clearTextField(MouseEvent event) {
        Object source = event.getSource();
        TextField field = (TextField) source;
        field.setText("");
    }


    //Disables ID
    //Cancels adding a part
    @FXML
    private void cancelAddPart(MouseEvent event) {
        boolean cancel = AlertMessage.cancel();
        if (cancel) {
            mainScreen(event);
        }
    }
    //Saves the added part and all information
    @FXML
    private void saveAddPart(MouseEvent event)throws IOException {
        resetFieldsStyle();
        String partName = name.getText();
        Double partPrice = Double.parseDouble(price.getText());
        Integer partStock = Integer.parseInt(count.getText());
        Integer partMax = Integer.valueOf(max.getText());
        Integer partMin = Integer.valueOf(min.getText());
            if (partName.isEmpty()||String.valueOf(partPrice).isEmpty()||
                    String.valueOf(partStock).isEmpty()||String.valueOf(partMin).isEmpty()
            ||String.valueOf(partMax).isEmpty()){
                Alert warning = new Alert(Alert.AlertType.WARNING);
                warning.setTitle("Missing Information");
                warning.setHeaderText("Empty Fields");
                warning.setContentText("Please ensure all fields are full");
                warning.showAndWait();
                return;
            } else if(Integer.valueOf(partMax)<=Integer.valueOf(partMin)){
                Alert warning = new Alert(Alert.AlertType.WARNING);
                warning.setTitle("Error");
                warning.setHeaderText("Error");
                warning.setContentText("Maximum product is less then minimum!");
                warning.showAndWait();
                return;
            }else{
                try{
                    int partID = partDAO.maxPartID();
                    Part part = new Part(partID,partName,partPrice,partStock,partMax,partMin);
                    partDAO.addPart(part);

                }catch (SQLException e){

                }
            }
        mainScreen(event);
    }

    //Reset Field Style
    private void resetFieldsStyle() {
        name.setStyle("-fx-border-color: darkgray");
        count.setStyle("-fx-border-color: darkgray");
        price.setStyle("-fx-border-color: darkgray");
        min.setStyle("-fx-border-color: darkgray");
        max.setStyle("-fx-border-color: darkgray");
    }
    //Call mainScreen event
    private void mainScreen(Event event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/MainScreen.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {

        }
    }

}
