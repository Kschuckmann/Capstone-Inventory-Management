package schuckmann.C868.Controllers;


import schuckmann.C868.DAO.partDAO;
import schuckmann.C868.model.Part;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * FXML Controller class
 *
 * @Author Karl Schuckmann
 */

/**
 * Logical error, parts of code were interfering with running
 * the FXLM properly
 */
public class ModifyPartController implements Initializable {
    public Part selectedPart;
    private int partID;

    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField price;
    @FXML
    private TextField count;
    @FXML
    private TextField min;
    @FXML
    private TextField max;

    @FXML
    private Button modifyPartSaveButton;
    /**
     * Starts the controller class.
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    @FXML
    private void clearTextField(MouseEvent event) {
        Object source = event.getSource();
        TextField field = (TextField) source;
        field.setText("");
    }

    public void pullParts(Part selectedPart){
        partID = selectedPart.getId();
        name.setText(selectedPart.getName());
        price.setText(Double.toString(selectedPart.getPrice()));
        count.setText(Integer.toString(selectedPart.getStock()));
        min.setText(Integer.toString(selectedPart.getMin()));
        max.setText(Integer.toString(selectedPart.getMax()));
    }
    //canceling the modify part section
    @FXML
    private void cancelModifyPart(MouseEvent event) {
        boolean cancel = cancel();
        if (cancel) {
            mainScreen(event);
        } else {
            return;
        }
    }
    //modify part section, including all buttons required for section
    @FXML
    private void saveModifyPart(MouseEvent event) throws  IOException{
        String partName = name.getText();
        Double partPrice = Double.parseDouble(price.getText());
        Integer partStock = Integer.parseInt(count.getText());
        Integer partMax = Integer.parseInt(max.getText());
        Integer partMin = Integer.parseInt(min.getText());
        if (partName.isEmpty()||String.valueOf(partPrice).isEmpty()||
                String.valueOf(partStock).isEmpty()||String.valueOf(partMin).isEmpty()
                ||String.valueOf(partMax).isEmpty()){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("Empty Fields");
            warning.setContentText("Please ensure all fields are full");
            warning.showAndWait();
            return;
        } else if(Integer.valueOf(partMax)<=Integer.valueOf(partMin)) {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Error");
            warning.setHeaderText("Error");
            warning.setContentText("Maximum product is less then minimum!");
            warning.showAndWait();
            return;
        }else{
            try{
                Part modPart = new Part(partID,partName,partPrice,partStock,partMin,partMax);
                partDAO.updatePart(modPart);
                System.out.println("Part modified");
            }catch (SQLException e){
                System.out.println(e);
            }
        }
            mainScreen(event);
    }


    private void mainScreen(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/MainScreen.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Cancel options appears, to cancel and confirm user choice
    private boolean cancel() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Cancel");
        alert.setHeaderText("Are you sure you want to cancel?");
        alert.setContentText("Click ok to confirm");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;

        }
    }
}