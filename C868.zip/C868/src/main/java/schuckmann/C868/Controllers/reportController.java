package schuckmann.C868.Controllers;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import schuckmann.C868.DAO.reportDAO;
import schuckmann.C868.model.Report;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ResourceBundle;

public class reportController implements Initializable {
    @FXML private TableView<Report> reportTable;
    @FXML private TableColumn<Report, String> part;
    @FXML private TableColumn<Report, Integer> stock;
    @FXML private TableColumn<Report, Timestamp> timestamp;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
      try{
            ObservableList<Report> reports = reportDAO.allPartReport();
            reportTable.setItems(reports);
        }catch (SQLException e){
            System.out.println(e);
        }
        part.setCellValueFactory(new PropertyValueFactory<>("name"));
        stock.setCellValueFactory(new PropertyValueFactory<>("stock"));
        timestamp.setCellValueFactory(new PropertyValueFactory<>("timestamp"));


    }
    @FXML
    private void backButton(MouseEvent actionEvent){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/MainScreen.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void exitButton (MouseEvent event) {
        Platform.exit();
    }
}
