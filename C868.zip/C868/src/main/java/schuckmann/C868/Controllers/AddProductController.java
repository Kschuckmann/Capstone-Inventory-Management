package schuckmann.C868.Controllers;

import javafx.scene.control.*;
import schuckmann.C868.DAO.productDAO;
import schuckmann.C868.model.Inventory;
import schuckmann.C868.model.Part;
import schuckmann.C868.model.Product;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Random;
import java.util.ResourceBundle;

/**
 * FXML Controller class
 *
 * Karl Schuckmann
 */

/**
 *RunTime Error, FXML Gui wouldn't launch, sections of code fixed with CI help
 */
public class AddProductController implements Initializable {


    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField price;
    @FXML
    private TextField count;
    @FXML
    private TextField min;
    @FXML
    private TextField max;
    @FXML
    private TextField search;
    @FXML
    private TableView<Part> partSearchTable;


    // Starts the controller class

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        generateProductID();
    }
    //Generates Product ID
    private void generateProductID() {
        boolean match;
        Random randomNum = new Random();
        Integer num = randomNum.nextInt(1000);
        if (Inventory.productListSize() == 0) {
            id.setText(num.toString());
        }
        if (Inventory.productListSize() == 1000) {
            AlertMessage.errorProduct(3, null);
        } else {
            match = generateNum(num);
            if (match == false) {
                id.setText(num.toString());
            } else {
                generateProductID();
            }
        }
        id.setText(num.toString());
    }
    //Generates Product number
    private boolean generateNum(Integer num) {
        Part match = Inventory.partLookup (num);
        return match != null;
    }

    //Clears text field on mouse button click
    @FXML
    private void clearTextField(MouseEvent event) {
        Object source = event.getSource();
        TextField field = (TextField) source;
        field.setText("");
    }


    // Cancels adding product on click
    @FXML
    private void cancelAddProduct(MouseEvent event
    ) {
        boolean cancel = AlertMessage.cancel();
        if (cancel) {
            mainScreen(event);
        }
    }
    // saves product on click
    @FXML
    private void saveAddProduct(MouseEvent event) {
        resetFieldsStyle();
        String productName = name.getText();
        Double productPrice = Double.parseDouble(price.getText());
        Integer productStock = Integer.parseInt(count.getText());
        Integer productMax = Integer.parseInt(max.getText());
        Integer productMin = Integer.parseInt(min.getText());
        if(productName.isEmpty()||String.valueOf(productPrice).isEmpty()||
                String.valueOf(productStock).isEmpty()||String.valueOf(productMin).isEmpty()
                ||String.valueOf(productMax).isEmpty()){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Missing Information");
            warning.setHeaderText("Empty Fields");
            warning.setContentText("Please ensure all fields are full");
            warning.showAndWait();
            return;
        } else if(Integer.valueOf(productMax)<=Integer.valueOf(productMin)){
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Error");
            warning.setHeaderText("Error");
            warning.setContentText("Maximum product is less then minimum!");
            warning.showAndWait();
            return;
        }else{
            try {
                int productID = productDAO.maxProductID();
                Product product = new Product(productID, productName, productPrice, productStock, productMin, productMax);
                productDAO.addProduct(product);
            }catch (SQLException e){
                System.out.println(e);
            }
        }
        mainScreen(event);
    }

    // Resets fields
    private void resetFieldsStyle() {
        name.setStyle("-fx-border-color: darkgray");
        count.setStyle("-fx-border-color: darkgray");
        price.setStyle("-fx-border-color: darkgray");
        min.setStyle("-fx-border-color: darkgray");
        max.setStyle("-fx-border-color: darkgray");
    }
    // Main Screen call
    private void mainScreen(Event event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/schuckmann/C868/MainScreen.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
        }


    }
}